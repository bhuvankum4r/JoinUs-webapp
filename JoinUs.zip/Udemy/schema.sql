use join_us;

create table users(
    email varchar(255) primary key,
    created_at timestamp default now()
);

insert into users(email) values ('Katie34@yahoo.com'), ('Tunde@gmail.com');

-- select earliest user in the format April 24th 2022
select date_format(min(created_at), "%M %D %Y") as earliest_users from users;

-- select the username of the earliest user
select * from users where created_at = (select min(created_at) from users);

-- group by month and total no, from descending order
select monthname(created_at) as month, count(monthname(created_at)) as count from users group by month order by count desc;

-- count of users who has yahoo
select count(email) as yahoo_users from users where email like '%yahoo%';

-- count of users with different providers
SELECT CASE 
         WHEN email LIKE '%@gmail.com' THEN 'gmail' 
         WHEN email LIKE '%@yahoo.com' THEN 'yahoo' 
         WHEN email LIKE '%@hotmail.com' THEN 'hotmail' 
         ELSE 'other' 
       end      AS provider, 
       Count(*) AS total_users 
FROM   users 
GROUP  BY provider 
ORDER  BY total_users DESC;